/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"rangeMessage":"* \u5165\u529b\ufffd?\ufffd\ufffd?\ufffd\u6570\u5024\ufffd?\ufffd\ufffd?\ufffd\u629e\u7bc4\u56f2\u5916\ufffd?\ufffd\ufffd?\ufffd\u3002", "invalidMessage":"* \u5165\u529b\ufffd?\ufffd\ufffd?\ufffd\u30c7\u30fc\u30bf\ufffd?\ufffd\u8a72\u5f53\ufffd?\ufffd\u308b\u3082\ufffd?\ufffd\ufffd?\ufffd\ufffd?\ufffd\u308a\ufffd?\ufffd\ufffd?\ufffd\u3093\u3002", "missingMessage":"* \u5165\u529b\ufffd?\ufffd\u5fc5\u9808\ufffd?\ufffd\ufffd?\ufffd\u3002"})