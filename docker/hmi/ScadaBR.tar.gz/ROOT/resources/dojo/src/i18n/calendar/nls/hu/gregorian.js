/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"field-weekday":"h\xe9t napja", "dateFormat-medium":"yyyy MMM d", "field-second":"m\xe1sodperc", "field-week":"h\xe9t", "pm":"d.u.", "timeFormat-full":"h:mm:ss a v", "months-standAlone-narrow":["J", "F", "M", "\ufffd?", "M", "J", "J", "A", "S", "O", "N", "D"], "am":"d.e.", "days-standAlone-narrow":["V", "H", "K", "Sz", "Cs", "P", "Sz"], "field-year":"\xe9v", "eras":["k.e.", "k.u."], "field-minute":"perc", "timeFormat-medium":"h:mm:ss a", "field-hour":"\xf3ra", "dateFormat-long":"yyyy MMMM d", "field-day":"nap", "field-dayperiod":"napszak", "field-month":"h\xf3nap", "dateFormat-short":"yyyy-M-d", "months-format-wide":["janu\xe1r", "febru\xe1r", "m\xe1rcius", "\xe1prilis", "m\xe1jus", "j\xfanius", "j\xfalius", "augusztus", "szeptember", "okt\xf3ber", "november", "december"], "field-era":"\xe9ra", "timeFormat-short":"h:mm a", "months-format-abbr":["jan", "feb", "m\xe1r", "apr", "m\xe1j", "j\xfan", "j\xfal", "aug", "sze", "okt", "nov", "dec"], "timeFormat-long":"h:mm:ss a z", "days-format-wide":["vas\xe1rnap", "h\xe9tf\u0151", "kedd", "szerda", "cs\xfct\xf6rt\xf6k", "p\xe9ntek", "szombat"], "dateFormat-full":"yyyy MMMM d, EEEE", "field-zone":"z\xf3na", "days-format-abbr":["Va", "H\xe9", "Ke", "Sze", "Cs\xfc", "P\xe9", "Szo"]})