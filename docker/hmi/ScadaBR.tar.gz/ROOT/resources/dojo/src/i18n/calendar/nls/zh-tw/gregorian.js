/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"dateFormat-medium":"yyyy'\u5e74'M'\u6708'd'\u65e5'", "field-second":"\u79d2", "field-week":"\u9031", "timeFormat-full":"ahh'\u6642'mm'\u5206'ss'\u79d2' z", "eras":["\u897f\u5143\ufffd?", "\u897f\u5143"], "field-year":"\u5e74", "field-minute":"\u5206\ufffd?\ufffd", "timeFormat-medium":"ahh:mm:ss", "field-hour":"\ufffd?\u6642", "dateFormat-long":"yyyy'\u5e74'M'\u6708'd'\u65e5'", "field-day":"\u6574\u65e5", "field-dayperiod":"\u65e5\u9593", "field-month":"\u6708", "dateFormat-short":"yy'\u5e74'M'\u6708'd'\u65e5'", "field-era":"\u5e74\u4ee3", "timeFormat-short":"ah:mm", "months-format-abbr":["1\u6708", "2\u6708", "3\u6708", "4\u6708", "5\u6708", "6\u6708", "7\u6708", "8\u6708", "9\u6708", "10\u6708", "11\u6708", "12\u6708"], "timeFormat-long":"ahh'\u6642'mm'\u5206'ss'\u79d2'", "field-weekday":"\u9031\u5929", "dateFormat-full":"yyyy'\u5e74'M'\u6708'd'\u65e5'EEEE", "field-zone":"\ufffd?\ufffd\u57df", "days-standAlone-narrow":["\u65e5", "\u4e00", "\u4e8c", "\u4e09", "\u56db", "\u4e94", "\u516d"], "am":"\u4e0a\ufffd?\ufffd", "days-format-abbr":["\u5468\u65e5", "\u5468\u4e00", "\u5468\u4e8c", "\u5468\u4e09", "\u5468\u56db", "\u5468\u4e94", "\u5468\u516d"], "pm":"\u4e0b\ufffd?\ufffd", "months-format-wide":["\u4e00\u6708", "\u4e8c\u6708", "\u4e09\u6708", "\u56db\u6708", "\u4e94\u6708", "\u516d\u6708", "\u4e03\u6708", "\u516b\u6708", "\ufffd?\u6708", "\ufffd??\u6708", "\ufffd??\u4e00\u6708", "\ufffd??\u4e8c\u6708"], "months-standAlone-narrow":["1\u6708", "2\u6708", "3\u6708", "4\u6708", "5\u6708", "6\u6708", "7\u6708", "8\u6708", "9\u6708", "10\u6708", "11\u6708", "12\u6708"], "days-format-wide":["\u661f\u671f\u65e5", "\u661f\u671f\u4e00", "\u661f\u671f\u4e8c", "\u661f\u671f\u4e09", "\u661f\u671f\u56db", "\u661f\u671f\u4e94", "\u661f\u671f\u516d"]})